This hack will make Scarface The World is Yours load dinput8.dll from the game directory.
Only tested with the 6mb exe, which should have an obfuscated call to CoCreateInstance at 0x6DE45B.

Inject this dll into the game somehow.
One way is to use Ultimate ASI loader (https://github.com/ThirteenAG/Ultimate-ASI-Loader).
Rename the file to .asi in that case.
