#include <windows.h>
#define DIRECTINPUT_VERSION (0x0800)
#include <dinput.h>
#include <assert.h>
#include <stdint.h>
#include "MemoryMgr.h"

#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "dinput8.lib")

HINSTANCE inst;

HRESULT __stdcall CoCreateInstance_hack(REFCLSID rclsid, LPUNKNOWN pUnkOuter, DWORD dwClsContext, REFIID riid, LPVOID *ppv)
{
	assert(pUnkOuter == NULL);
	assert(dwClsContext == 1);
	return DirectInput8Create(inst, DIRECTINPUT_VERSION, riid, ppv, pUnkOuter);
}

void
patch(void)
{
	InjectHook(0x6DE45B, CoCreateInstance_hack);
	Nop(0x6DE47A, 3);
}

BOOL WINAPI
DllMain(HINSTANCE hInst, DWORD reason, LPVOID)
{
	inst = hInst;
	if(reason == DLL_PROCESS_ATTACH)
		patch();

	return TRUE;
}
